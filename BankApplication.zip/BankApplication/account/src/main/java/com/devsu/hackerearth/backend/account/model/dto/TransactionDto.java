package com.devsu.hackerearth.backend.account.model.dto;

import java.util.Date;
import com.devsu.hackerearth.backend.account.model.Transaction;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class TransactionDto {

	private Long id;
    private Date date;
	private String type;
	private double amount;
	private double balance;
	private Long accountId;

	public TransactionDto() {}

	public static TransactionDto from(Transaction transaction) {
		return new TransactionDto(
			transaction.getId(),
			transaction.getDate(),
			transaction.getType(),
			transaction.getAmount(),
			transaction.getBalance(),
			transaction.getAccountId()
		);
	}

	public static Transaction toEntity(TransactionDto dto) {
		Transaction transaction = new Transaction();
		transaction.setId(dto.getId());
		transaction.setDate(dto.getDate());
		transaction.setType(dto.getType());
		transaction.setAmount(dto.getAmount());
		transaction.setBalance(dto.getBalance());
		transaction.setAccountId(dto.getAccountId());
		return transaction;
	}
}
