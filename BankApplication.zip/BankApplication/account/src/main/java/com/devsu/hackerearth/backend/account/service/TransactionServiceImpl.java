package com.devsu.hackerearth.backend.account.service;

import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.devsu.hackerearth.backend.account.model.Account;
import com.devsu.hackerearth.backend.account.model.Transaction;
import com.devsu.hackerearth.backend.account.model.dto.BankStatementDto;
import com.devsu.hackerearth.backend.account.model.dto.TransactionDto;
import com.devsu.hackerearth.backend.account.repository.AccountRepository;
import com.devsu.hackerearth.backend.account.repository.TransactionRepository;

@Service
public class TransactionServiceImpl implements TransactionService {

	private final TransactionRepository transactionRepository;
    
    private final AccountRepository accountRepository;

	public TransactionServiceImpl(TransactionRepository transactionRepository, AccountRepository accountRepository) {
		this.transactionRepository = transactionRepository;
        this.accountRepository = accountRepository;
	}

    @Override
    public List<TransactionDto> getAll() {
        return transactionRepository.findAll()
            .stream()
            .map(TransactionDto::from)
            .collect(Collectors.toList());
    }

    @Override
    public TransactionDto getById(Long id) {
        Transaction tx = transactionRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Transaction not found"));
		return TransactionDto.from(tx);
    }

    @Override
    public TransactionDto create(TransactionDto dto) {
        Transaction tx = TransactionDto.toEntity(dto);
        Transaction saved = transactionRepository.save(tx);
		return TransactionDto.from(saved);
    }

    @Override
    public List<BankStatementDto> getAllByAccountClientIdAndDateBetween(Long clientId, Date start, Date end) {
		List<Account> accounts = accountRepository.findByClientId(clientId);

        return accounts.stream()
            .flatMap(account -> {
                List<Transaction> transactions = transactionRepository
                    .findByDateBetweenAndAccountId(start, end, account.getId());
                return transactions.stream()
                    .map(tx -> new BankStatementDto(
                        tx.getDate(),
                        clientId.toString(),
                        account.getNumber(),
                        account.getType(),
                        account.getInitialAmount(),
                        account.isActive(),
                        tx.getType(),
                        tx.getAmount(),
                        tx.getBalance()
                    ));
            })
            .collect(Collectors.toList());
    }

    @Override
    public TransactionDto getLastByAccountId(Long accountId) {
        return transactionRepository.findTopByAccountIdOrderByDateDesc(accountId)
            .map(TransactionDto::from)
            .orElse(null);
    }
    
}
