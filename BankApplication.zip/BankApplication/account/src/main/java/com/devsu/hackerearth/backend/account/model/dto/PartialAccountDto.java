package com.devsu.hackerearth.backend.account.model.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class PartialAccountDto {

	private Boolean isActive;
	private String type;
	private Double initialAmount;

	public PartialAccountDto(boolean isActive, String type, Double initialAmount) {
		this.isActive = isActive;
		this.type = type;
		this.initialAmount = initialAmount;
	}
}
