package com.devsu.hackerearth.backend.account.controller;

import java.util.Date;
import java.util.List;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.devsu.hackerearth.backend.account.model.dto.BankStatementDto;
import com.devsu.hackerearth.backend.account.model.dto.TransactionDto;
import com.devsu.hackerearth.backend.account.service.TransactionService;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/transactions")
@RequiredArgsConstructor
public class TransactionController {

	private final TransactionService transactionService;

	@GetMapping
	public List<TransactionDto> getAllTransactions() {
		return transactionService.getAll();
	}

	@GetMapping("/{id}")
	public ResponseEntity<TransactionDto> getTransactionById(@PathVariable Long id) {
		return ResponseEntity.ok(transactionService.getById(id));
	}

	@PostMapping
	public ResponseEntity<TransactionDto> createTransaction(@RequestBody TransactionDto transactionDto){
		return ResponseEntity.status(201).body(transactionService.create(transactionDto));
	}

	@GetMapping("/last/{accountId}")
	public ResponseEntity<TransactionDto> getLastTransaction(@PathVariable Long accountId) {
		return ResponseEntity.ok(transactionService.getLastByAccountId(accountId));
	}

	@GetMapping("/statement")
	public ResponseEntity<List<BankStatementDto>> getBankStatement(
			@RequestParam Long clientId,
			@RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) Date start,
			@RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) Date end) {
		List<BankStatementDto> statement = transactionService
				.getAllByAccountClientIdAndDateBetween(clientId, start, end);
		return ResponseEntity.ok(statement);
	}

	@GetMapping("/clients/{clientId}/report")
	public ResponseEntity<List<BankStatementDto>> report(
			@PathVariable Long clientId,
			@RequestParam @DateTimeFormat(pattern = "yyyy-MM-dd") Date start,
			@RequestParam @DateTimeFormat(pattern = "yyyy-MM-dd") Date end) {
		List<BankStatementDto> report = transactionService
				.getAllByAccountClientIdAndDateBetween(clientId, start, end);
		return ResponseEntity.ok(report);
	}
}
