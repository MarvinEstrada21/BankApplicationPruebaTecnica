package com.devsu.hackerearth.backend.account.model.dto;

import com.devsu.hackerearth.backend.account.model.Account;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@AllArgsConstructor
@EqualsAndHashCode
public class AccountDto {

	private Long id;
	private String number;
	private String type;
	private double initialAmount;
	private boolean isActive;
	private Long clientId;

	public AccountDto() {}

	public static AccountDto from(Account account) {
		return new AccountDto(
			account.getId(), 
			account.getNumber(), 
			account.getType(),
			account.getInitialAmount(),
			account.isActive(), 
			account.getClientId()
		);
	}

	public static Account toEntity(AccountDto dto) {
		Account account = new Account();
		account.setId(dto.getId());
		account.setNumber(dto.getNumber());
		account.setType(dto.getType());
		account.setInitialAmount(dto.getInitialAmount());
		account.setActive(dto.isActive());
		account.setClientId(dto.getClientId());
		return account;
	}
}
