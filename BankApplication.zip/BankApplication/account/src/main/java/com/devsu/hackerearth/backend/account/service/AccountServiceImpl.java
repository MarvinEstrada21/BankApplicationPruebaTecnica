package com.devsu.hackerearth.backend.account.service;

import java.util.List;
import java.util.stream.Collectors;
import org.springframework.stereotype.Service;
import com.devsu.hackerearth.backend.account.mapper.AccountMapper;
import com.devsu.hackerearth.backend.account.model.Account;
import com.devsu.hackerearth.backend.account.model.dto.AccountDto;
import com.devsu.hackerearth.backend.account.model.dto.PartialAccountDto;
import com.devsu.hackerearth.backend.account.repository.AccountRepository;
import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class AccountServiceImpl implements AccountService {

	private final AccountRepository accountRepository;
    private final AccountMapper accountMapper;

    @Override
    public List<AccountDto> getAll() {
        return accountRepository.findAll().stream()
            .map(AccountDto::from)
            .collect(Collectors.toList());
    }

    @Override
    public AccountDto getById(Long id) {
        Account account = accountRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Account not found"));
		return AccountDto.from(account);
    }

    @Override
    public AccountDto create(AccountDto accountDto) {
        Account account = accountMapper.toEntity(accountDto);
        Account saved = accountRepository.save(account);
        return accountMapper.toDto(saved);
    }

    @Override
    public AccountDto update(AccountDto accountDto) {
        Account account = accountRepository.findById(accountDto.getId())
            .orElseThrow(() -> new RuntimeException("Account not found"));
        account.setNumber(accountDto.getNumber());
        account.setType(accountDto.getType());
        account.setInitialAmount(accountDto.getInitialAmount());
        account.setActive(accountDto.isActive());
        account.setClientId(accountDto.getClientId());
		return AccountDto.from(accountRepository.save(account));
    }

    @Override
    public AccountDto partialUpdate(Long id, PartialAccountDto partialDto) {
        Account account = accountRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Account not found"));

        if (partialDto.getIsActive() != null) {
            account.setActive(partialDto.getIsActive());
        }

		return AccountDto.from(accountRepository.save(account));
    }

    @Override
    public void deleteById(Long id) {
        accountRepository.deleteById(id);
    }
    
}
