package com.devsu.hackerearth.backend.account;

import com.devsu.hackerearth.backend.account.controller.AccountController;
import com.devsu.hackerearth.backend.account.model.dto.AccountDto;
import com.devsu.hackerearth.backend.account.model.dto.PartialAccountDto;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class AccountControllerTest {

    @Mock
    private AccountController accountController;

    private AccountDto accountDto;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);

        accountDto = new AccountDto();
        accountDto.setId(1L);
        accountDto.setNumber("ACC123");
        accountDto.setType("AHORRO");
        accountDto.setInitialAmount(1000.0);
        accountDto.setActive(true);
        accountDto.setClientId(10L);
    }

    @Test
    public void testGet() {
        when(accountController.get(1L))
                .thenReturn(ResponseEntity.ok(accountDto));

        ResponseEntity<AccountDto> response = accountController.get(1L);
        assertEquals(200, response.getStatusCodeValue());
        assertEquals("ACC123", response.getBody().getNumber());
    }

    @Test
    public void testGetAll() {
        List<AccountDto> list = List.of(accountDto);
        when(accountController.getAll()).thenReturn(ResponseEntity.ok(list));

        ResponseEntity<List<AccountDto>> response = accountController.getAll();
        assertEquals(1, response.getBody().size());
    }

    @Test
    public void testDelete() {
        when(accountController.delete(1L))
                .thenReturn(ResponseEntity.ok().build());

        ResponseEntity<Void> response = accountController.delete(1L);
        assertEquals(200, response.getStatusCodeValue());
    }

    @Test
    public void testPartialUpdate() {
        PartialAccountDto partialDto = new PartialAccountDto(true, "ACC456", 1500.0);
        when(accountController.partialUpdate(eq(1L), any()))
                .thenReturn(ResponseEntity.ok(accountDto));

        ResponseEntity<AccountDto> response = accountController.partialUpdate(1L, partialDto);
        assertEquals(200, response.getStatusCodeValue());
        assertEquals("ACC123", response.getBody().getNumber());
    }

    @Test
    public void testUpdate() {
        AccountDto dto = new AccountDto();
        dto.setNumber("ACC123");
        dto.setType("Savings");
        dto.setInitialAmount(1000.0);
        dto.setActive(true);

        when(accountController.update(any())).thenReturn(ResponseEntity.ok(dto));

        ResponseEntity<AccountDto> response = accountController.update(dto);
        assertEquals(200, response.getStatusCodeValue());
        assertEquals("ACC123", response.getBody().getNumber());
    }
}