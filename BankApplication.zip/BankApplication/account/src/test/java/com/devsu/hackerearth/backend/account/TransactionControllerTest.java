package com.devsu.hackerearth.backend.account;

import com.devsu.hackerearth.backend.account.controller.TransactionController;
import com.devsu.hackerearth.backend.account.model.dto.BankStatementDto;
import com.devsu.hackerearth.backend.account.model.dto.TransactionDto;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;

import java.util.Date;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class TransactionControllerTest {

    @Mock
    private TransactionController transactionController;

    private TransactionDto transactionDto;
    private BankStatementDto bankStatementDto;
    private Date startDate;
    private Date endDate;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);

        transactionDto = new TransactionDto();
        transactionDto.setId(1L);
        transactionDto.setAmount(300.0);

        bankStatementDto = new BankStatementDto();
        // setear campos si es necesario

        startDate = new Date();
        endDate = new Date();
    }

    @Test
    public void testGetAll() {
        List<TransactionDto> list = List.of(transactionDto);
        when(transactionController.getAll()).thenReturn(ResponseEntity.ok(list));

        ResponseEntity<List<TransactionDto>> response = transactionController.getAll();
        assertEquals(1, response.getBody().size());
    }

    @Test
    public void testGetById() {
        when(transactionController.get(1L)).thenReturn(ResponseEntity.ok(transactionDto));

        ResponseEntity<TransactionDto> response = transactionController.get(1L);
        assertEquals(1L, response.getBody().getId());
    }

    @Test
    public void testCreate() {
        when(transactionController.create(any())).thenReturn(ResponseEntity.ok(transactionDto));

        ResponseEntity<TransactionDto> response = transactionController.create(transactionDto);
        assertEquals(300.0, response.getBody().getAmount());
    }

    @Test
    public void testGetLast() {
        when(transactionController.getLast(1L)).thenReturn(ResponseEntity.ok(transactionDto));

        ResponseEntity<TransactionDto> response = transactionController.getLast(1L);
        assertEquals(300.0, response.getBody().getAmount());
    }

    @Test
    public void testGetBankStatement() {
        List<BankStatementDto> list = List.of(bankStatementDto);
        when(transactionController.getBankStatement(10L, startDate, endDate)).thenReturn(ResponseEntity.ok(list));

        ResponseEntity<List<BankStatementDto>> response = transactionController.getBankStatement(10L, startDate, endDate);
        assertEquals(1, response.getBody().size());
    }

    @Test
    public void testReport() {
        List<BankStatementDto> list = List.of(bankStatementDto);
        when(transactionController.report(10L, startDate, endDate)).thenReturn(ResponseEntity.ok(list));

        ResponseEntity<List<BankStatementDto>> response = transactionController.report(10L, startDate, endDate);
        assertEquals(1, response.getBody().size());
    }
}
