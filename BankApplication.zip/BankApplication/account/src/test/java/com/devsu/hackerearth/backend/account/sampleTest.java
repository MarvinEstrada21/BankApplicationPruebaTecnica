/*package com.devsu.hackerearth.backend.account;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import com.devsu.hackerearth.backend.account.controller.AccountController;
import com.devsu.hackerearth.backend.account.model.dto.AccountDto;
import com.devsu.hackerearth.backend.account.service.AccountService;

public class sampleTest {

    private AccountService accountService;
    private AccountController accountController;

    @BeforeEach
    void setUp() {
        accountService = mock(AccountService.class);
        accountController = new AccountController(accountService);
    }

    @Test
    void createAccountTest() {
        AccountDto newAccount = new AccountDto();
        newAccount.setType("savings");
        newAccount.setInitialAmount(0.0);
        newAccount.setActive(true);
    
        AccountDto expectedResponse = new AccountDto();
        expectedResponse.setType("savings");
        expectedResponse.setInitialAmount(0.0);
        expectedResponse.setActive(true);
    
        Mockito.when(accountService.create(Mockito.any(AccountDto.class)))
               .thenReturn(expectedResponse);
    
        AccountDto response = accountController.create(newAccount);
    
        assertEquals(expectedResponse.getType(), response.getType());
        assertEquals(expectedResponse.getInitialAmount(), response.getInitialAmount());
        assertEquals(expectedResponse.isActive(), response.isActive());
    }
}
*/