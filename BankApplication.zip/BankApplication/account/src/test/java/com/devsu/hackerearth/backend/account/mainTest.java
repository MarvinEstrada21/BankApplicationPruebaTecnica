package com.devsu.hackerearth.backend.account;

import com.devsu.hackerearth.backend.account.controller.AccountController;
import com.devsu.hackerearth.backend.account.controller.TransactionController;
import com.devsu.hackerearth.backend.account.model.dto.AccountDto;
import com.devsu.hackerearth.backend.account.model.dto.BankStatementDto;
import com.devsu.hackerearth.backend.account.model.dto.PartialAccountDto;
import com.devsu.hackerearth.backend.account.model.dto.TransactionDto;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;

import java.util.*;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;

@DisplayName("mainTest/account")
public class mainTest {

    @Mock
    private AccountController accountController;

    @Mock
    private TransactionController transactionController;

    @InjectMocks
    private AccountDto accountDto;

    @InjectMocks
    private TransactionDto transactionDto;

    @InjectMocks
    private BankStatementDto bankStatementDto;

    private Date startDate;
    private Date endDate;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);

        accountDto = new AccountDto();
        accountDto.setId(1L);
        accountDto.setNumber("ACC123");
        accountDto.setType("AHORRO");
        accountDto.setInitialAmount(1000.0);
        accountDto.setActive(true);
        accountDto.setClientId(10L);

        transactionDto = new TransactionDto();
        transactionDto.setId(1L);
        transactionDto.setAmount(300.0);

        bankStatementDto = new BankStatementDto();
        startDate = new Date();
        endDate = new Date();
    }

    @Test
    @DisplayName("Cuenta por id")
    public void testGetAccount() {
        when(accountController.get(1L)).thenReturn(ResponseEntity.ok(accountDto));
        ResponseEntity<AccountDto> response = accountController.get(1L);
        assertEquals(200, response.getStatusCodeValue());
        assertEquals("ACC123", response.getBody().getNumber());
    }

    @Test
    @DisplayName("Todas las cuentas")
    public void testGetAllAccounts() {
        List<AccountDto> list = List.of(accountDto);
        when(accountController.getAll()).thenReturn(ResponseEntity.ok(list));
        ResponseEntity<List<AccountDto>> response = accountController.getAll();
        assertEquals(1, response.getBody().size());
    }

    @Test
    @DisplayName("Borrar cuenta")
    public void testDeleteAccount() {
        when(accountController.delete(1L)).thenReturn(ResponseEntity.ok().build());
        ResponseEntity<Void> response = accountController.delete(1L);
        assertEquals(200, response.getStatusCodeValue());
    }

    @Test
    @DisplayName("Actualizar parcialmente la cuenta")
    public void testPartialUpdateAccount() {
        PartialAccountDto partialDto = new PartialAccountDto(true, "ACC456", 1500.0);
        when(accountController.partialUpdate(eq(1L), any())).thenReturn(ResponseEntity.ok(accountDto));
        ResponseEntity<AccountDto> response = accountController.partialUpdate(1L, partialDto);
        assertEquals(200, response.getStatusCodeValue());
        assertEquals("ACC123", response.getBody().getNumber());
    }

    @Test
    @DisplayName("Actualizar cuenta")
    public void testUpdateAccount() {
        AccountDto dto = new AccountDto();
        dto.setNumber("ACC123");
        dto.setType("Savings");
        dto.setInitialAmount(1000.0);
        dto.setActive(true);
        when(accountController.update(any())).thenReturn(ResponseEntity.ok(dto));
        ResponseEntity<AccountDto> response = accountController.update(dto);
        assertEquals(200, response.getStatusCodeValue());
        assertEquals("ACC123", response.getBody().getNumber());
    }

    @Test
    @DisplayName("Todas las transacciones")
    public void testGetAllTransactions() {
        List<TransactionDto> list = List.of(transactionDto);
        when(transactionController.getAll()).thenReturn(ResponseEntity.ok(list));
        ResponseEntity<List<TransactionDto>> response = transactionController.getAll();
        assertEquals(1, response.getBody().size());
    }

    @Test
    @DisplayName("Transaccion por id")
    public void testGetTransactionById() {
        when(transactionController.get(1L)).thenReturn(ResponseEntity.ok(transactionDto));
        ResponseEntity<TransactionDto> response = transactionController.get(1L);
        assertEquals(1L, response.getBody().getId());
    }

    @Test
    @DisplayName("Crear transaccion")
    public void testCreateTransaction() {
        when(transactionController.create(any())).thenReturn(ResponseEntity.ok(transactionDto));
        ResponseEntity<TransactionDto> response = transactionController.create(transactionDto);
        assertEquals(300.0, response.getBody().getAmount());
    }

    @Test
    @DisplayName("Última transaccion")
    public void testGetLastTransaction() {
        when(transactionController.getLast(1L)).thenReturn(ResponseEntity.ok(transactionDto));
        ResponseEntity<TransactionDto> response = transactionController.getLast(1L);
        assertEquals(300.0, response.getBody().getAmount());
    }

    @Test
    @DisplayName("Estado banco")
    public void testGetBankStatement() {
        List<BankStatementDto> list = List.of(bankStatementDto);
        when(transactionController.getBankStatement(10L, startDate, endDate)).thenReturn(ResponseEntity.ok(list));
        ResponseEntity<List<BankStatementDto>> response = transactionController.getBankStatement(10L, startDate,
                endDate);
        assertEquals(1, response.getBody().size());
    }

    @Test
    @DisplayName("Reporte")
    public void testReport() {
        List<BankStatementDto> list = List.of(bankStatementDto);
        when(transactionController.report(10L, startDate, endDate)).thenReturn(ResponseEntity.ok(list));
        ResponseEntity<List<BankStatementDto>> response = transactionController.report(10L, startDate, endDate);
        assertEquals(1, response.getBody().size());
    }
}
