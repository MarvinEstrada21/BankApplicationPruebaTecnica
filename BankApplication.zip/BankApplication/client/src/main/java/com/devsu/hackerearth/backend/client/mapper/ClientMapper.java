package com.devsu.hackerearth.backend.client.mapper;

import com.devsu.hackerearth.backend.client.model.Client;
import com.devsu.hackerearth.backend.client.model.dto.ClientDto;

public class ClientMapper {
    
    public ClientDto toDto(Client client) {
        return new ClientDto(
            client.getId(),
			client.getDni(),
			client.getName(),
			client.getPassword(),
			client.getGender(),
			client.getAge(),
			client.getAddress(),
			client.getPhone(),
			client.isActive()
        );
    }

    public Client toEntity(ClientDto dto) {
        Client client = new Client();
		client.setId(dto.getId());
		client.setDni(dto.getDni());
		client.setName(dto.getName());
		client.setPassword(dto.getPassword());
		client.setGender(dto.getGender());
		client.setAge(dto.getAge());
		client.setAddress(dto.getAddress());
		client.setPhone(dto.getPhone());
		client.setActive(dto.isActive());
		return client;
    }

}
