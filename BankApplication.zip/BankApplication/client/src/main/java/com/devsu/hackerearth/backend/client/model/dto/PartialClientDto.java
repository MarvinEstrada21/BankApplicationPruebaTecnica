package com.devsu.hackerearth.backend.client.model.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class PartialClientDto {

    private boolean isActive;
    private String phone;
    private String address;

    public PartialClientDto(boolean isActive, String phone, String address) {
        this.isActive = isActive;
        this.phone = phone;
        this.address = address;
    }
}
