package com.devsu.hackerearth.backend.client.service;

import java.util.List;
import java.util.stream.Collectors;
import org.springframework.stereotype.Service;
import com.devsu.hackerearth.backend.client.model.Client;
import com.devsu.hackerearth.backend.client.model.dto.ClientDto;
import com.devsu.hackerearth.backend.client.model.dto.PartialClientDto;
import com.devsu.hackerearth.backend.client.repository.ClientRepository;

@Service
public class ClientServiceImpl implements ClientService {

	private final ClientRepository clientRepository;

	public ClientServiceImpl(ClientRepository clientRepository) {
		this.clientRepository = clientRepository;
	}

	@Override
	public List<ClientDto> getAll() {
		return clientRepository.findAll()
			.stream()
			.map(ClientDto::from)
			.collect(Collectors.toList());
	}

	@Override
	public ClientDto getById(Long id) {
		Client client = clientRepository.findById(id)
			.orElseThrow(() -> new RuntimeException("Client not found"));
		return ClientDto.from(client);
	}

	@Override
	public ClientDto create(ClientDto clientDto) {
		Client client = ClientDto.toEntity(clientDto);
		Client saved = clientRepository.save(client);
		return ClientDto.from(saved);
	}

	@Override
	public ClientDto update(ClientDto clientDto) {
		Client existing = clientRepository.findById(clientDto.getId())
			.orElseThrow(() -> new RuntimeException("Client not found"));

		existing.setDni(clientDto.getDni());
		existing.setName(clientDto.getName());
		existing.setPassword(clientDto.getPassword());
		existing.setGender(clientDto.getGender());
		existing.setAge(clientDto.getAge());
		existing.setAddress(clientDto.getAddress());
		existing.setPhone(clientDto.getPhone());
		existing.setActive(clientDto.isActive());

		Client updated = clientRepository.save(existing);
		return ClientDto.from(updated);
	}

	@Override
    public ClientDto partialUpdate(Long id, PartialClientDto partialDto) {
	    Client client = clientRepository.findById(id)
			.orElseThrow(() -> new RuntimeException("Client not found"));

		if (partialDto.getPhone() != null) {
			client.setPhone(partialDto.getPhone());
		}

		if (partialDto.getAddress() != null) {
			client.setAddress(partialDto.getAddress());
		}

		return ClientDto.from(clientRepository.save(client));
    }
	
	@Override
	public void deleteById(Long id) {
		clientRepository.deleteById(id);
	}
}
