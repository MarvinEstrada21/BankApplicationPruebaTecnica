package com.devsu.hackerearth.backend.client.service;

import java.util.List;
import java.util.stream.Collectors;
import org.springframework.stereotype.Service;
import com.devsu.hackerearth.backend.client.mapper.ClientMapper;
import com.devsu.hackerearth.backend.client.model.Client;
import com.devsu.hackerearth.backend.client.model.dto.ClientDto;
import com.devsu.hackerearth.backend.client.model.dto.PartialClientDto;
import com.devsu.hackerearth.backend.client.repository.ClientRepository;

@Service
public class ClientServiceImpl implements ClientService {

	private final ClientRepository clientRepository;
	private ClientMapper clientMapper;

	public ClientServiceImpl(ClientRepository clientRepository) {
		this.clientRepository = clientRepository;
	}

	@Override
    public List<ClientDto> getAll() {
        return clientRepository.findAll()
                .stream()
                .map(clientMapper::toDto)
                .collect(Collectors.toList());
    }

    @Override
    public ClientDto getById(Long id) {
        Client client = clientRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Client not found"));
        return clientMapper.toDto(client);
    }

    @Override
    public ClientDto create(ClientDto clientDto) {
        Client client = clientMapper.toEntity(clientDto);
        Client saved = clientRepository.save(client);
        return clientMapper.toDto(saved);
    }

    @Override
    public ClientDto update(ClientDto clientDto) {
        Client client = clientMapper.toEntity(clientDto);
        Client updated = clientRepository.save(client);
        return clientMapper.toDto(updated);
    }

    @Override
    public ClientDto partialUpdate(Long id, PartialClientDto partialClientDto) {
        Client existing = clientRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Client not found"));

        if (partialClientDto.getPhone() != null) {
            existing.setPhone(partialClientDto.getPhone());
        }
        if (partialClientDto.getAddress() != null) {
            existing.setAddress(partialClientDto.getAddress());
        }
        existing.setActive(partialClientDto.isActive());

        Client saved = clientRepository.save(existing);
        return clientMapper.toDto(saved);
    }

    @Override
    public void deleteById(Long id) {
        clientRepository.deleteById(id);
    }
}
