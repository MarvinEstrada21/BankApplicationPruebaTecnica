package com.devsu.hackerearth.backend.client.model.dto;

import com.devsu.hackerearth.backend.client.model.Client;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ClientDto {

	private Long id;
	private String dni;
	private String name;
	private String password;
	private String gender;
	private int age;
	private String address;
	private String phone;
	private boolean isActive;

	public static ClientDto from(Client client) {
		return new ClientDto(
			client.getId(),
			client.getDni(),
			client.getName(),
			client.getPassword(),
			client.getGender(),
			client.getAge(),
			client.getAddress(),
			client.getPhone(),
			client.isActive()
		);
	}

	public static Client toEntity(ClientDto dto) {
		Client client = new Client();
		client.setId(dto.getId());
		client.setDni(dto.getDni());
		client.setName(dto.getName());
		client.setPassword(dto.getPassword());
		client.setGender(dto.getGender());
		client.setAge(dto.getAge());
		client.setAddress(dto.getAddress());
		client.setPhone(dto.getPhone());
		client.setActive(dto.isActive());
		return client;
	}
}

