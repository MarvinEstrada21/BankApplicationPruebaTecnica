/*package com.devsu.hackerearth.backend.client;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import com.devsu.hackerearth.backend.client.controller.ClientController;
import com.devsu.hackerearth.backend.client.model.dto.ClientDto;
import com.devsu.hackerearth.backend.client.service.ClientService;

public class sampleTest {

    private ClientService clientService;
    private ClientController clientController;

    @BeforeEach
    void setUp() {
        clientService = mock(ClientService.class);
        clientController = new ClientController(clientService);
    }

    @Test
    void createClientTest() {
        // Arrange
        ClientDto newClient = new ClientDto();
        newClient.setPhone("99999999");
        newClient.setAddress("Some Street");
        newClient.setActive(true);

        ClientDto expectedResponse = newClient;

        when(clientService.create(any(ClientDto.class))).thenReturn(expectedResponse);

        // Act
        ClientDto response = clientController.create(newClient);

        // Assert
        assertEquals(expectedResponse.getPhone(), response.getPhone());
        assertEquals(expectedResponse.getAddress(), response.getAddress());
        assertEquals(expectedResponse.isActive(), response.isActive());
    }
}
*/