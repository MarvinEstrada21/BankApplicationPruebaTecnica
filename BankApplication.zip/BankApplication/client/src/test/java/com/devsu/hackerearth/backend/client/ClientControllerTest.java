package com.devsu.hackerearth.backend.client;

import com.devsu.hackerearth.backend.client.controller.ClientController;
import com.devsu.hackerearth.backend.client.model.dto.ClientDto;
import com.devsu.hackerearth.backend.client.model.dto.PartialClientDto;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class ClientControllerTest {

    @Mock
    private ClientController clientController;

    private ClientDto clientDto;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);

        clientDto = new ClientDto();
        clientDto.setId(1L);
        clientDto.setName("Juan Pérez");
        clientDto.setAddress("Calle Falsa 123");
        clientDto.setActive(true);
    }

    @Test
    public void testGet() {
        when(clientController.get(1L)).thenReturn(ResponseEntity.ok(clientDto));

        ResponseEntity<ClientDto> response = clientController.get(1L);
        assertEquals(200, response.getStatusCodeValue());
        assertEquals("Juan Pérez", response.getBody().getName());
    }

    @Test
    public void testGetAll() {
        List<ClientDto> list = List.of(clientDto);
        when(clientController.getAll()).thenReturn(ResponseEntity.ok(list));

        ResponseEntity<List<ClientDto>> response = clientController.getAll();
        assertEquals(1, response.getBody().size());
    }

    @Test
    public void testCreate() {
        when(clientController.create(any())).thenReturn(ResponseEntity.ok(clientDto));

        ResponseEntity<ClientDto> response = clientController.create(clientDto);
        assertEquals("Juan Pérez", response.getBody().getName());
    }

    @Test
    public void testUpdate() {
        when(clientController.update(any())).thenReturn(ResponseEntity.ok(clientDto));

        ResponseEntity<ClientDto> response = clientController.update(clientDto);
        assertEquals("Juan Pérez", response.getBody().getName());
    }

    @Test
    public void testPartialUpdate() {
        PartialClientDto partialDto = new PartialClientDto(true, "999999999", "Nueva Dirección 456");
    
        when(clientController.partialUpdate(eq(1L), any()))
            .thenReturn(ResponseEntity.ok(clientDto));
    
        ResponseEntity<ClientDto> response = clientController.partialUpdate(1L, partialDto);
        assertEquals("Juan Pérez", response.getBody().getName());
    }

    @Test
    public void testDelete() {
        when(clientController.delete(1L)).thenReturn(ResponseEntity.ok().build());

        ResponseEntity<Void> response = clientController.delete(1L);
        assertEquals(200, response.getStatusCodeValue());
    }
}