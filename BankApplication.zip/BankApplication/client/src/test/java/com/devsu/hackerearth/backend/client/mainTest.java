package com.devsu.hackerearth.backend.client;

import com.devsu.hackerearth.backend.client.controller.ClientController;
import com.devsu.hackerearth.backend.client.model.dto.ClientDto;
import com.devsu.hackerearth.backend.client.model.dto.PartialClientDto;
import com.devsu.hackerearth.backend.client.service.ClientService;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.eq;

@DisplayName("mainTest/client")
public class mainTest {

    @Mock
    private ClientService clientService;

    @InjectMocks
    private ClientController clientController;

    private ClientDto clientDto;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);

        clientDto = new ClientDto();
        clientDto.setId(1L);
        clientDto.setName("Juan Pérez");
        clientDto.setPhone("999999999");
        clientDto.setAddress("Calle Falsa 123");
        clientDto.setActive(true);
    }

    @Test
    @DisplayName("Cliente por ID")
    public void testGet() {
        when(clientService.getById(1L)).thenReturn(clientDto);
        ResponseEntity<ClientDto> response = clientController.get(1L);
        assertEquals(200, response.getStatusCodeValue());
        assertEquals("Juan Pérez", response.getBody().getName());
    }

    @Test
    @DisplayName("Todas los clientes")
    public void testGetAll() {
        when(clientService.getAll()).thenReturn(List.of(clientDto));
        ResponseEntity<List<ClientDto>> response = clientController.getAll();
        assertEquals(1, response.getBody().size());
    }

    @Test
    @DisplayName("Crear cliente")
    public void testCreate() {
        when(clientService.create(any())).thenReturn(clientDto);
        ResponseEntity<ClientDto> response = clientController.create(clientDto);
        assertEquals("Juan Pérez", response.getBody().getName());
    }

    @Test
    @DisplayName("Actualizar cliente")
    public void testUpdate() {
        when(clientService.update(any())).thenReturn(clientDto);
        ResponseEntity<ClientDto> response = clientController.update(clientDto);
        assertEquals("Juan Pérez", response.getBody().getName());
    }

    @Test
    @DisplayName("Actualizar parcialmente el cliente")
    public void testPartialUpdate() {
        PartialClientDto partialDto = new PartialClientDto(true, "999999999", "Nueva Dirección 456");

        when(clientService.partialUpdate(eq(1L), any())).thenReturn(clientDto);
        ResponseEntity<ClientDto> response = clientController.partialUpdate(1L, partialDto);
        assertEquals("Juan Pérez", response.getBody().getName());
    }

    @Test
    @DisplayName("Borrar cliente")
    public void testDelete() {
        ResponseEntity<Void> response = clientController.delete(1L);
        assertEquals(200, response.getStatusCodeValue());
    }
}
